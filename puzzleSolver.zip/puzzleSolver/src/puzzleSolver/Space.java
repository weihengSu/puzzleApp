package puzzleSolver;


import puzzleSolver.Column;

public class Space {
	public int row;
	public int col;
	public int tile_name;
	public Space left;
	public Space right;
	public Space top;
	public Space down;
	public Column column;


}
