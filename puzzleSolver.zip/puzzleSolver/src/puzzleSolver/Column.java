package puzzleSolver;

import puzzleSolver.Space;


public class Column extends Space {

	public int size;
	public String numCol;
	public Column left;
	public Column right;

}
